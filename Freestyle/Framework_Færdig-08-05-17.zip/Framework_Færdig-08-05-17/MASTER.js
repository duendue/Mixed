//Utilizing the "webshot" framework to grab a screenshot from an external sketch
var webshot = require("webshot");
var webshot1 = require("webshot");

//Options for the screenshot
var options = {
  streamType: "png",
  //Delay for when webshot takes a screenshot of the sketch
  renderDelay: 60000,
  windowSize: {
    width: 2000,
    height: 1000,
  },
  shotSize: {
    width:"1000",
    height:"1000",
  },
  shotOffset: {
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
  }
};

var options1 = {
  streamType: "png",
  //Delay for when webshot takes a screenshot of the sketch
  renderDelay: 60000,
  windowSize: {
    width: 2000,
    height: 1000,
  },
  shotSize: {
    width:"1000",
    height:"1000",
  },
  shotOffset: {
    left: 1000,
    right: 0,
    top: 0,
    bottom: 0,
  }
};

//Delays the creations of the screenshots 11 hours
setTimeout(screenshotDelay, 1000*60*60*11);

function screenshotDelay() {
	//How often to generate new screenshots
	Screenshot();
	Screenshot1();
	//Generates screenshots once every 24 hours
	setInterval(Screenshot, 1000*60*60*24);
	setInterval(Screenshot1, 1000*60*60*24);
}

//Delay for when the timer for the daily post should be executed
setTimeout(tweetDailyTimer, 1000*60*60*12);

//Makes the bot tweet a daily tweet every 24 hours
function tweetDailyTimer() {
	tweetDaily();
  	setInterval(tweetDaily, 1000*60*60*24);
}

//Makes the bot tweet a official statement for everyone
function tweetDaily() {
		console.log('TIME FOR THE DAILY BULLETIN FROM THE NATION')
	  	var filename = 'OfficialStatement.png';
	  	var params = {
	    	encoding: 'base64'
	  	}
	    var b64 = fs.readFileSync(filename, params);

	    T.post('media/upload', { media_data: b64 }, uploadedDaily);

			function uploadedDaily(err, data, response) {
				var id = data.media_id_string;
				var tweet = {
					status: 'Daily bulletin from The Great Nation:',
					media_ids: [id]
					}
				T.post('statuses/update', tweet, tweetedImageDaily);
			}

				function tweetedImageDaily(err, data, response) {
				  if (err) {
				  	  console.log("Error publishing official statement - DAILY");
				  } else {
				      console.log("Official statement published - DAILY");
				  }
			}
}

//Grabs a screenshot from an external source
function Screenshot(){
imagename = "RawData.png"

	webshot1("https://duendue.github.io/Mixed/GitHub_FOLDER/", imagename, options, (err) => {
	if(err){
	   return console.log(err);
	}
	  console.log("RawData succesfully created");
	});
}

function Screenshot1(){
imagename = "OfficialStatement.png"

	webshot("https://duendue.github.io/Mixed/GitHub_FOLDER/", imagename, options1, (err) => {
	if(err){
	   return console.log(err);
	}
	  console.log("OfficialStatement succesfully created");
	});
}

console.log('Starting up truthful government')

//This bot takes use of the "Twit" API client. Its a Twitter API client that works
//with node.
var Twit = require('twit');

//The configuration files for the twitter account is saved in a different
//location and loaded here. It loads from the file "config.js"
var config = require('./config');
var T = new Twit(config);

var fs = require('fs');

//Variable used to count the amount of times the chosen string have been sent
//to the bot
var tagcounter = 0;

//Resets certain counters in the bot
function resetTimer() {
	//Counter for how many "active" citizens. Resets once every day, or when
	//the bot restarts
	tagcounter = 0;
	//Neat little counter used for making the bot only post once when it reaches
	//enough active citizens
	cooldown = 0;
}
//Runs the function once daily
setInterval(resetTimer, 1000*60*60*24)

//The "stream" command is used, because the program constantly needs
//to check with the Twitter server
var stream = T.stream('user');
stream.on('tweet', tweetEvent);

//This function checks if the bot account should tweet or not.
function tweetEvent(eventMsg) {

	function tweetImage() {
		  	var filename = 'RawData.png';
		  	var params = {
		    encoding: 'base64'
	  	}
	    var b64 = fs.readFileSync(filename, params);

	    T.post('media/upload', { media_data: b64 }, uploaded);

	    function uploaded(err, data, response) {
	      var id = data.media_id_string;
		  var tweet = {
		  	  //Posts a tweet to the person who tweeted the correct string to the bot
		      status: '@' + from + ' DATA obtained and ready for wordprocessing_module.exe',
		      media_ids: [id]
		  }
	      T.post('statuses/update', tweet, tweetedImage);
	    }

	    //Log data for succesful and unsuccesful image posts
		function tweetedImage(err, data, response) {
		  if (err) {
		  	  console.log("Error publishing official statement - REPLY");
		  } else {
		      console.log("DATA leaked to a curious citizen- IMAGE");
		  }
		}
	}
	//Theses variables are used to make the coding and reading process easier
	//for the programmer. "eventMsg" is a callback function needed when
	//communicating data with Twitters servers. The paths refers to files 
	//in a JSON format, and are present in every tweet.
	var replyto = eventMsg.in_reply_to_screen_name;
	var text = eventMsg.text;
	var from = eventMsg.user.screen_name;

	//Variable for the specific tag used
	var chosentag = '@TheGreatLeadr #source'

	//Logs the communication between twitter accounts to the console
	console.log(from + ' sent a tweet to ' + replyto);

	//Setting up the criteria for the interaction with the bot. You can see this
	//as two different options. Either A: The tweet to the bot account is correct
	//								Or B: The tweet to the bot account is incorrect
	//Depending on the tweet meets case A or B, the bot will send different messages.
	//
	//Case A (correct):
	if(replyto === 'TheGreatLeadr' && text === chosentag) {
		//var newtweet = '@' + from + ' The truth? Yesss...';
		tweetImage();
	} else {
	//Case B (incorrect):
		if(replyto === 'TheGreatLeadr') {
			var newtweet = '@' + from + ' Thanks for your participation. Stand by for more official bulletins from The Great Leader';
			tweetIt(newtweet);
		}
	}
	//Counts the amount of times the specific string below has been posted since the
	//bot started running.
	if (text === chosentag) {
		tagcounter = tagcounter + 1;
	}
}
//This function is used in the cases above. It makes the account tweet. 
function tweetIt(txt) {

	var tweet = {
		status: txt
	}

	//Makes the bot account post a status update.
	T.post('statuses/update', tweet, tweeted);

	//Nested function that logs strings to the console. Makes it easier to see
	//if the bot works or not
	function tweeted(err, data, response) {
		if (err) {
			console.log("Errhm, Houston we got a problem");
		} else {
			console.log("Citizen participation noticed - MESSAGE");
		}
	}
}
//Cooldown used for making the bot only post once when there is enough
//active citizens
var cooldown = 0;

//Makes the bot post an specific image when there are enough "active" followers
function tweetImageActive() {
	//Only if "cooldown" is under 1 will the bot post the image
	if(cooldown<=1){
		console.log('ACTIVE LEVEL REACHED - POSTING THE SOURCE FOR EVERYONE')
	  	var filename = 'RawData.png';
	  	var params = {
	    	encoding: 'base64'
	  	}
	    var b64 = fs.readFileSync(filename, params);

	    T.post('media/upload', { media_data: b64 }, uploadedActive);

	    function uploadedActive(err, data, response) {
	      var id = data.media_id_string;
		  var tweet = {
			  status: 'Due to immense pressure from the citizens of The Great Nation, the following data has been leaked',
		      media_ids: [id]
		  }
	      T.post('statuses/update', tweet, tweetedImageActive);
	    }

			function tweetedImageActive(err, data, response) {
			  if (err) {
				  console.log("Error publishing official datasource - ACTIVE");
			  } else {
			      console.log("Official datasource posted - ACTIVE");
			  }
			}
	}
}
//Logs the amount of followers the bot everytime the interval has passed.
//10000 milliseconds equals to 10 seconds in this example.
setInterval(getFollowers, 10000);

//Grabs the data from the specific twitter name the bot is using.
function getFollowers() {
	T.get('users/show', { screen_name: 'TheGreatLeadr' },  function (err, data, response) {
	//Logs the response to the console.
  	console.log('There are currently ' + data.followers_count + ' citizens in the great nation');

	  		//Logs the amount responses to the bot with the specific string to the console.
	  		//Dubbed here as "active citizens".
	  		console.log('Amount of active citizens: ' + tagcounter);

	  		//Calculates the "citizen"/"active citizen" ratio and acts respectively.
	  		if (data.followers_count >= tagcounter * 2) {

	  		//If the follower count is more than double the amount the specific string
	  		//has been sent to the bot account, it will log this message to the console.
	  		//(Aka. closed government)
			console.log('Need more active citizens to reveal the source');
		} else {

			//If the active amount of users (people who tweet the specific string to the bot)
			//is more than 50% of the followers, this log will show
			console.log('NATION REACHED ACTIVE LEVEL');

			//Makes the cooldown trick do wonders
			cooldown++;

			//Calls the "Active" level image function to be executed
			tweetImageActive();
		}
	})
}