module.exports = {
	consumer_key:         'RjUsIgjzCUR3EW3bj8eLDNOk3',
  	consumer_secret:      'dTh093CuW5OZq9W5IRuuNatyfGoQIJmgdBiHdw3ruxvFueWiuj',
 	access_token:         '855506714346565632-C8hGnptJYPAXyYMp6Ym4eriaQXzZh6O',
  	access_token_secret:  'f0OgFARkaYxo8oom12bNSASrQvj0d2qe0bRM7T6k7wtWj',
}